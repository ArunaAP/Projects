<?php
    include_once('includes/header.php');
?>
<!DOCTYPE html>

<html lang="en">
	<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Soft Metric Life Insurance</title>
	<link rel="stylesheet" href="styles.css">
	</head>


<!-----------------------------------add paragraph-------------------------->	




<div class="whoWeAreimg">
<img src="Images/Who we are img.jpg"  width="450px" height="640px">
</div>

<div class="whoWe">
	<h2 class="mtitle">Who We Are</h2>
<br>
<h3 class="para">Soft Metric Life Insurance is Sri Lanka's biggest and undisputed pioneer in extra security. 
Going from one solidarity to another with creative items and administrations, while supporting our trust and notoriety among individuals, 
we have developed to turn into an easily recognized name in each edge of the country and a benchmark of life coverage in Sri Lanka. 
With our huge reach and through our profoundly specific deals power we have figured out how to ensure the lives and manufacture long lasting associations with right around 1 million residents, 
and we will keep on pointing higher until we have accomplished our vision of securing each Sri Lankan family with disaster protection and retirement arrangements.</h3>

<br><br>
<hr>
<h2 style="color:#fec20f" class="title">Vision</h2>

<h2 class="sub-para">"To take the responsibility to ensure the life and the retirement planing of every family, who join thier hands with us"</h2>
<br><br>
<hr>
<h2 style= "color:#fec20f" class="title">Mission</h2>

<h2 class="sub-para">" To turn into the most trusted, acclaimed, and reformist extra security organization in Sri Lanka, by giving need-based disaster protection answers for our clients, perceiving and remunerating our workers, making fruitful associations with partners, and guaranteeing supportable strategic policies for reasonable, capable, and productive development, 
while leaving a more modest carbon impression on earth."</h2>


</div>



<br><br>


<!-----------------------Footer------------------------->
<?php
    include_once('includes/footer.php');
?>

</body>	
</html>
