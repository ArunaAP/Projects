<?php

require_once('connection.php');

if (isset($_POST['Submit'])) {
	$Password=$_POST['Password'];
	$email=$_POST['email'];
	 
$result_set=mysqli_query($con,"UPDATE `policyholder` SET `Password`='$Password' WHERE `email`='".$email."'");


}


?>	
	


<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Soft Metric Life Insurance</title>
	<link rel="stylesheet" href="Styles/styles.css">
	<style>
	

.box{
	width: 400px;
    height: 300px;
    background: #20b2aa;
    margin: 30px auto;
    box-shadow: 0 25px 20px gray;
    padding: 25px;
	}
	
	.hdtxt{
	font-size: 25px;
    color: #1c1f4c;
	padding-top: 20px;
	padding-bottom: 6px;
	}
	
	.input{
	width: 150px;
    font-size: 20px;

	}
	
	.btn{
		background-color: #fec20f;
		color: white;
		border-radius: 12px;
		padding: 4px 16px;
		font-size: 18px;
		
	}
	
	.weltxt{
		font-style: italic;
		color: #1c1f4c;
		font-size: 32px;
	}
	
	
	</style>
	</head>
	
	<div class="hero-image">
  <div class="hero-text"> 
		<img class="logo" src="Images/Logo.png" width="230" height="230">
		
		<center>
    <div class="hederposition">
		<h1>Soft Metric Life Insurance</h1>
		
		<h3>Insuring Your Future Dreams</h3>
    <br>
		</center>
    </div>
    </div>
    </div>


<!---Add navigation bar menu---->
	<hr class="hr1">
		
	<body>	
	
			<div class="navbar">
				<a href="Home page.php">Home</a>
				<a href="Who we are.php">Who We Are</a>
				<div class="dropdown">
			<button class="dropbtn">Life Insurance <i class="fa fa-caret-down"></i>
			</button>
			<div class="dropdown-content">
			<a href="Goldern infinity policy.php">Golden Infinity</a>
			<a href="Silver journey policy.php">Silver Journey</a>
			<a href="Bronze pensioner policy.php">Bronze Pensioner</a>
			</div>
			</div> 
				<a href="Contact us.php">Contact Us</a>
        <div class="right">
				<a href="Buy online.php">Buy Online</a>
				<a href="Pay online.php">Pay Online</a>	
			<div class="dropdown">
			<button class="dropbtn">Login <i class="fa fa-caret-down"></i>
			</button>
			<div class="dropdown-content">
			<a href="Admin login.php">Admin</a>
			<a href="Agent login.php">Agent</a>
			<a href="Policyholder login.php">Policyholder</a>
      </div>
			</div>
			</div> 
		</div>	
	<br>



<center>
<div class="weltxt">Reset Password</div>
<div class="box">
<form method="post">
<label>Enter your Email</label><br><br>
<input type="text" placeholder="email" name="email" value="<?php echo '".$email."'; ?>"> <br><br>
Change Your Password :<br><br>
<input type="text" name="Password" value="<?php echo '".$Password."'; ?>"> <br><br>
<button type="submit" name="Submit" class="btn"> Change </button><br><br>
<a href="Policyholder login.php">Login with my new password</a>
</form>
</center>	
	

<hr class="hr3">
	
<footer class="footer">

<div class="leftFooter">
Quick Links
<br><br>
<a href="Who we are.php">Who We Are</a><a href="Contact us.php">Contact Us</a>

<div class="rightFooter">
Soft Metric Life Insurance
<br>
75,Millenium Drive, Malabe
<br>
Tel:011 750 3000
<br>
info.softmetric@gmail.com
<br>
</div>
</div>

<center>
<a href="https://www.facebook.com/Soft-Metric-Life-Insurance-101575288775739"><img src="Images/facebook.png" alt="fbicon" width="30px" height="30px"></a>
  <a href="https://www.instagram.com/softmetriclifeinsurance/"><img src="Images/insta.png" alt="intaicon"width="30px" height="30px"></a>
  <a href="https://www.linkedin.com/in/soft-metric-life-insurance-088982211"><img src="Images/linkedin.png" alt="inicon"width="30px" height="30px"></a>
  
<h5 style="font-weight:bold; font-size:13px;">All Rights Reserved by: Soft Metric Life Insurance ©2021<i class="fa fa-copyright"style="font-size:12px;color:white;"></i> </h5>
</center>
</footer>		

</body>	
</html>