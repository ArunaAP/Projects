
  <div class="hero-image">
  <div class="hero-text"> 
		<a href="Home page.php"><img class="logo" src="Images/Logo.png" width="230" height="220"></a>
		
		<center>
    <div class="hederposition">
		<h1 class="maintext">Soft Metric Life Insurance</h1>
		
		<h3 class="tagline">Insuring Your Future Dreams</h3>

		</center>
    </div>
    </div>
    </div>

	<style>
		.dropdown-content{
			float: left;
			margin-right:20px;
		}
		.tagline{
			font-size:14px;
			
		}
		.maintext{
			margin-bottom:1px;
		}


	</style>


<!---Add navigation bar menu---->
	<hr class="hr1">
		
	<body>	
			<div class="navbar">
				<a href="Home page.php">Home</a>
				<a href="Who we are.php">Who We Are</a>
				<div class="dropdown">
			<button class="dropbtn">Life Insurance <i class="fa fa-caret-down"></i>
			</button>
			<div class="dropdown-content">
			<a href="Goldern infinity policy.php">Golden Infinity</a>
			<a href="Silver journey policy.php">Silver Journey</a>
			<a href="Bronze pensioner policy.php">Bronze Pensioner</a>
			</div>
			</div> 
				<a href="Contact us.php">Contact Us</a>
        <div class="right">
				<a href="Premium calculator.php">Premium Calculator</a>
				<a href="Policyholder login.php">Pay Online</a>	
			<div class="dropdown">
			<button class="dropbtn">Login <i class="fa fa-caret-down"></i>
			</button>
			<div class="dropdown-content">
			<a href="Admin login.php">Admin</a>
			<a href="Agent login.php">Agent</a>
			<a href="Policyholder login.php">Policyholder</a>
      </div>
			</div>
			</div> 
		</div>	
  
