<hr class="hr3">
	
<footer class="footer">

<div class="leftFooter">
Quick Links
<br><br>
<a href="Who we are.php">Who We Are</a><a href="Contact us.php">Contact Us</a>

<div class="rightFooter">
Soft Metric Life Insurance
<br>
75,Millenium Drive, Malabe
<br>
Tel:011 750 3000
<br>
info.softmetric@gmail.com
<br>
</div>
</div>
<br>
<center>
<a href="https://www.facebook.com/Soft-Metric-Life-Insurance-101575288775739"><img src="Images/facebook.png" alt="fbicon" width="30px" height="30px"></a>
  <a href="https://www.instagram.com/softmetriclifeinsurance/"><img src="Images/insta.png" alt="intaicon"width="30px" height="30px"></a>
  <a href="https://www.linkedin.com/in/soft-metric-life-insurance-088982211"><img src="Images/linkedin.png" alt="inicon"width="30px" height="30px"></a>
  
<h5 style="font-weight:bold; font-size:13px;">All Rights Reserved by: Soft Metric Life Insurance ©2021<i class="fa fa-copyright"style="font-size:12px;color:white;"></i> </h5>

</footer>		
</center>	